Black Pearl Conky by Ninquitassar (2012)
Special credits to Iacoporosso
created on Arch Linux
WMFS window manager

----> http://ninquitassar.deviantart.com/
----> support and bugs reporting here

1) You need conky with lua support
2) Read all conkyrc, correct paths and set to your configuration.
3) If something do not work, watch in the net what program you need (ex. hddtemp daemon)
4) If you want to add something (ex. if you have a multi-core system), adjust 'offset' and 'voffset' to move items correctly.
5) Probably you want to set some rings: edit .lua files and add/remove (setting 'x' and 'y' coordinates, radius and thickness). If you will tell me your ideas, I thank you! :)
6) Music display is set to Music Player Daemon (MPD). There is also a commented version for Exaile. If you use another player, search a configuration on the net.
7) Enjoy! :)
